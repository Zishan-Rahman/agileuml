#include <stdlib.h>
#include <math.h>

/* C header for OclRandom library */

struct OclRandom
{ int ix; 
  int iy; 
  int iz;
  char* distribution; 
  double bernoulliP;  
  double normalMean; 
  double normalVariance; 
  double uniformLower; 
  double uniformUpper; 
  double poissonLambda; 
};

struct OclRandom* _defaultInstanceOclRandom = NULL; 

struct OclRandom* newOclRandom(void)
{ struct OclRandom* res = 
    (struct OclRandom*) malloc(sizeof(struct OclRandom)); 

res->ix = 1001; 
  res->iy = 781;
  res->iz = 913; 
  res->distribution = "uniform"; 
  res->bernoulliP = 0.0; 
  res->normalMean = 0.0; 
  res->normalVariance = 1.0; 
  res->uniformLower = 0.0; 
  res->uniformUpper = 1.0; 
  res->poissonLambda = 1.0; 
  return res; 
} 

struct OclRandom* defaultInstanceOclRandom(void)
{ if (_defaultInstanceOclRandom == NULL) 
  { _defaultInstanceOclRandom = newOclRandom(); } 
  return _defaultInstanceOclRandom; 
}

struct OclRandom* newOclRandom_Seed(long n)
{ struct OclRandom* res = 
    (struct OclRandom*) malloc(sizeof(struct OclRandom)); 

  res->ix = (int) (n % 30269);
  res->iy = (int) (n % 30307);
  res->iz = (int) (n % 30323);
  res->distribution = "uniform"; 
  res->bernoulliP = 0.0; 
  res->normalMean = 0.0; 
  res->normalVariance = 1.0; 
  res->uniformLower = 0.0; 
  res->uniformUpper = 1.0; 
  res->poissonLambda = 1.0; 
  return res;
} 

struct OclRandom* newOclRandomBernoulli(double p)
{ struct OclRandom* res = 
    (struct OclRandom*) malloc(sizeof(struct OclRandom)); 
  
  res->ix = 1001; 
  res->iy = 781;
  res->iz = 913; 
  res->distribution = "bernoulli"; 
  res->bernoulliP = p; 
  res->normalMean = 0.0; 
  res->normalVariance = 1.0; 
  res->uniformLower = 0.0; 
  res->uniformUpper = 1.0; 
  res->poissonLambda = 1.0; 
  return res;
} 

struct OclRandom* newOclRandomNormal(double mu, double vari)
{ struct OclRandom* res = 
    (struct OclRandom*) malloc(sizeof(struct OclRandom)); 
  
  res->ix = 1001; 
  res->iy = 781;
  res->iz = 913; 
  res->distribution = "normal"; 
  res->bernoulliP = 0.0; 
  res->normalMean = mu; 
  res->normalVariance = vari; 
  res->uniformLower = 0.0; 
  res->uniformUpper = 1.0; 
  res->poissonLambda = 1.0; 
  return res;
} 

struct OclRandom* newOclRandomUniform(double lwr, double upr)
{ struct OclRandom* res = 
    (struct OclRandom*) malloc(sizeof(struct OclRandom)); 
  
  res->ix = 1001; 
  res->iy = 781;
  res->iz = 913; 
  res->distribution = "uniform"; 
  res->bernoulliP = 0.0; 
  res->normalMean = 0.0; 
  res->normalVariance = 1.0; 
  res->uniformLower = lwr; 
  res->uniformUpper = upr; 
  res->poissonLambda = 1.0; 
  return res;
} 

struct OclRandom* newOclRandomPoisson(double lam)
{ struct OclRandom* res = 
    (struct OclRandom*) malloc(sizeof(struct OclRandom)); 
  
  res->ix = 1001; 
  res->iy = 781;
  res->iz = 913; 
  res->distribution = "poisson"; 
  res->bernoulliP = 0.0; 
  res->normalMean = 0.0; 
  res->normalVariance = 1.0; 
  res->uniformLower = 0.0; 
  res->uniformUpper = 1.0; 
  res->poissonLambda = lam; 
  return res;
} 

void setSeeds_OclRandom(struct OclRandom* self, int x, int y, int z)
{ self->ix = x;
  self->iy = y;
  self->iz = z;
}

void setSeed_OclRandom(struct OclRandom* self, long n)
{ self->ix = (int) (n % 30269);
  self->iy = (int) (n % 30307);
  self->iz = (int) (n % 30323);
}

double nrandom_OclRandom(struct OclRandom* self)
{ self->ix = ( self->ix * 171 ) % 30269; 
  self->iy = ( self->iy * 172 ) % 30307; 
  self->iz = ( self->iz * 170 ) % 30323; 
  return ((self->ix / 30269.0) + (self->iy / 30307.0) + (self->iz / 30323.0));
}

double nextDouble_OclRandom(struct OclRandom* self)
{ double r = nrandom_OclRandom(self);
  return ( r - floor(r) );
}

double nextFloat_OclRandom(struct OclRandom* self)
{ return nextDouble_OclRandom(self); }

double nextGaussian_OclRandom(struct OclRandom* self)
{ double d = nrandom_OclRandom(self);
  return d*2.0 - 3.0; 
}

int nextInt_OclRandom(struct OclRandom* self, int n)
{ double d = nextDouble_OclRandom(self);
  return (int) floor(d*n);
} 

int nextIntInt_OclRandom(struct OclRandom* self)
{ return nextInt_OclRandom(self, 2147483647); }

long nextLong_OclRandom(struct OclRandom* self)
{ double d = nextDouble_OclRandom(self); 
  return (long) floor(d*9223372036854775807L); 
}

unsigned char nextBoolean_OclRandom(struct OclRandom* self)
{ double d = nextDouble_OclRandom(self);
  if (d > 0.5)
  { return TRUE; }
  return FALSE; 
} 

int nextBernoulli_OclRandom(struct OclRandom* self, double p)
{ double d = nextDouble_OclRandom(self);
  if (d > p)
  { return 0; }
  return 1; 
} 

double nextNormal_OclRandom(struct OclRandom* self, double mu, double vari)
{ double d = 0.0; 
  int i = 0; 
  for ( ; i < 12; i++) 
  { d = d + nextDouble_OclRandom(self); }
  d = d - 6; 
  return mu + d*sqrt(vari); 
}

double nextUniform_OclRandom(struct OclRandom* self, double lwr, double upr)
{ double d = nextDouble_OclRandom(self);
  return d*(upr - lwr) + lwr;
} 

double nextPoisson_OclRandom(struct OclRandom* self, double lam)
{ double x = 0.0;  
  double p = exp(-lam);  
  double s = p; 
  double u = nextDouble_OclRandom(self); 

  while (u > s) 
  { x = x + 1;
    p = p*lam/x;
    s = s + p;
  } 
  return x;
}

double next_OclRandom(struct OclRandom* self)
{ if (strcmp(self->distribution,"normal") == 0)
  { return nextNormal_OclRandom(self, self->normalMean, 
                                self->normalVariance); 
  }

  if (strcmp(self->distribution, "bernoulli") == 0)
  { return nextBernoulli_OclRandom(self, self->bernoulliP); }

  if (strcmp(self->distribution, "uniform") == 0)
  { return nextUniform_OclRandom(self, self->uniformLower, self->uniformUpper); }

  if (strcmp(self->distribution, "poisson") == 0)
  { return nextPoisson_OclRandom(self, self->poissonLambda); }

  return nextDouble_OclRandom(self);
} 

double mean_OclRandom(struct OclRandom* self)
{ if (strcmp(self->distribution,"normal") == 0)
  { return self->normalMean; }

  if (strcmp(self->distribution, "bernoulli") == 0)
  { return self->bernoulliP; }

  if (strcmp(self->distribution, "uniform") == 0)
  { return 0.5*(self->uniformUpper + self->uniformLower); }

  if (strcmp(self->distribution, "poisson") == 0)
  { return self->poissonLambda; }

  return 0.5;
} 

double variance_OclRandom(struct OclRandom* self)
{ if (strcmp(self->distribution,"normal") == 0)
  { return self->normalVariance; }

  if (strcmp(self->distribution, "bernoulli") == 0)
  { return (self->bernoulliP)*(1 - self->bernoulliP); }

  if (strcmp(self->distribution, "uniform") == 0)
  { double diff = self->uniformUpper - self->uniformLower; 
    return diff*diff/12.0; 
  }

  if (strcmp(self->distribution, "poisson") == 0)
  { return self->poissonLambda; }

  return 1.0/12.0; 
} 

int randomComparator(const void* s1, const void* s2)
{ int rx = rand();
  double d = (1.0*rx)/RAND_MAX;
  if (d > 0.5)
  { return 1; }
  if (d < 0.5)
  { return -1; }
  return 0; 
}


void** randomiseSequence_OclRandom(void* col[])
{ /* Sort col with a random comparator */
  void** res = treesort(col, randomComparator); 
  return res; 
} 


void* randomElement_OclRandom(void* col[])
{ int n = length(col); 
  if (n == 0) 
  { return NULL; }
  int rx = rand();
  double d = (1.0*rx)/RAND_MAX;
  int ind = (int) floor(n*d); 
  return col[ind]; 
} 
 
char* randomString_OclRandom(int n)
{ char* chrs = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
  char* res = ""; 
  int i = 0; 
  for ( ; i < n; i++) 
  { int code = (int) floor(54*(1.0*rand())/RAND_MAX);
    char* schr = (char*) calloc(2,sizeof(char));
    schr[0] = chrs[code]; 
    schr[1] = '\0';   
    res = concatenateStrings(res, schr); 
  } 
  return res; 
}

void** randomElements_OclRandom(void* col[], int n)
{ int sze = length(col); 
  if (sze == 0) 
  { return NULL; }
  void** res = (void**) calloc(n+1, sizeof(void*)); 

  while (length(res) < n)
  { int rx = rand();
    double d = (1.0*rx)/RAND_MAX;
    int ind = (int) floor(sze*d); 
    res = append(res, col[ind]); 
  }
  return res;  
} 

void** randomUniqueElements_OclRandom(void* col[], int n)
{ int sze = length(col); 
  if (sze == 0) 
  { return NULL; }
  void** res = (void**) calloc(n+1, sizeof(void*)); 

  while (length(res) < n)
  { int rx = rand();
    double d = (1.0*rx)/RAND_MAX;
    int ind = (int) floor(sze*d); 
    if (isIn(col[ind], res)) { }
    else 
    { res = append(res, col[ind]); }
  }
  return res;  
} 
