import javax.swing.JFrame; 
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel; // drawing support
import java.util.List; 
import java.util.ArrayList; 

public class ScatterPlot extends JPanel
{ List x = new ArrayList();
  List y = new ArrayList();
  double xstep = 400.0/8;
  double ystep = 400.0/5;
  int[][] weights = new int[10][7]; 

  public void setData(List xvalues, List yvalues)
  { x = xvalues;
    y = yvalues;
  }

  public void paintComponent(Graphics g)
  { super.paintComponent(g);

    g.drawLine(50,50,50,650); /* Y-axis */ 
    g.drawLine(50,650,650,650); /* X-axis */ 

    for (int i = 0; i < 10; i++) 
    { g.drawString("" + i, (int) Math.round(50 + i*xstep), 660); } 

    for (int j = 0; j < 7; j++) 
    { g.drawString("" + j, 40, (int) Math.round(600 - j*ystep)); } 

    for (int i = 0; i < 10; i++) 
    { for (int j = 0; j < 7; j++) 
      { weights[i][j] = 0; } 
    } 
 
    for (int i = 0; i < x.size(); i++)
    { Double xv = (Double) x.get(i);
      Double yv = (Double) y.get(i);
      int xvalue = (int) Math.round(xv.doubleValue()); 
      int yvalue = (int) Math.round(yv.doubleValue()); 
      weights[xvalue][yvalue]++; 
    }

    for (int i = 0; i < x.size(); i++)
    { Double xv = (Double) x.get(i);
      Double yv = (Double) y.get(i);
      double xplot = 50 + xv.doubleValue() * xstep;
      double yplot = 600 - yv.doubleValue() * ystep;
      g.setColor(Color.BLACK);
      int xcoord = (int) Math.round(xplot); 
      int ycoord = (int) Math.round(yplot); 
      g.fillOval(xcoord, ycoord, 5, 5); 
      int xvalue = (int) Math.round(xv.doubleValue()); 
      int yvalue = (int) Math.round(yv.doubleValue()); 
      g.drawString("" + weights[xvalue][yvalue], xcoord + 6, ycoord);  
    }

  }
  
  
  public void open()
  { JFrame app = new JFrame("Scatter plot");
    
    app.add(this);
    app.setSize(700, 700);
    app.setVisible(true);
  }
}
