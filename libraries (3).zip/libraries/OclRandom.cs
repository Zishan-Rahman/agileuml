
    class OclRandom
    {
        private int ix; // internal
        private int iy; // internal
        private int iz; // internal
        private string distribution; // internal
        private double bernoulliP; // internal
        private double normalMean; // internal
        private double normalVariance; // internal
        private double uniformLower; // internal
        private double uniformUpper; // internal
        private double poissonLambda; // internal

          private static OclRandom _defaultInstanceOclRandom = null;

        public OclRandom()
        {
            ix = 0;
            iy = 0;
            iz = 0;
            distribution = "uniform";
            bernoulliP = 0.0;
            normalMean = 0.0;
            normalVariance = 1.0;
            uniformLower = 0.0;
            uniformUpper = 1.0;
            poissonLambda = 1.0;
        }

        public static OclRandom defaultInstanceOclRandom()
        {
            if (OclRandom._defaultInstanceOclRandom == null)
            {
                OclRandom._defaultInstanceOclRandom = OclRandom.newOclRandom();
            }
            return OclRandom._defaultInstanceOclRandom;
        }

        public void setix(int ixval)
        { ix = ixval; }

        public void setiy(int iyval)
        { iy = iyval; }

        public int getiz()
        { return iz; }

        public int getix()
        { return ix; }

        public int getiy()
        { return iy; }

        public void setiz(int izval)
        { iz = izval; }

       public void setdistribution(string distribution_x) { distribution = distribution_x; }

        public void setbernoulliP(double bernoulliP_x) { bernoulliP = bernoulliP_x; }

        public void setnormalMean(double normalMean_x) { normalMean = normalMean_x; }

        public void setnormalVariance(double normalVariance_x) { normalVariance = normalVariance_x; }

        public void setuniformLower(double uniformLower_x) { uniformLower = uniformLower_x; }


        public void setuniformUpper(double uniformUpper_x) { uniformUpper = uniformUpper_x; }

        public void setpoissonLambda(double poissonLambda_x) { poissonLambda = poissonLambda_x; }

public string getdistribution() { return distribution; }

        public double getbernoulliP() { return bernoulliP; }

        public double getnormalMean() { return normalMean; }

        public double getnormalVariance() { return normalVariance; }

        public double getuniformLower() { return uniformLower; }

        public double getuniformUpper() { return uniformUpper; }

        public double getpoissonLambda() { return poissonLambda; }


         public static OclRandom newOclRandom()
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix(1001);
            rd.setiy(781);
            rd.setiz(913);
            rd.setdistribution("uniform");
            result = rd;
            return result;
        }


        public static OclRandom newOclRandom(long n)
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix((int)n % 30269);
            rd.setiy((int)(n % 30307));
            rd.setiz((int)(n % 30323));
            rd.setdistribution("uniform");
            result = rd;
            return result;
        }

        public static OclRandom newOclRandom_Seed(long n)
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix(((int)(n % 30269)));
            rd.setiy(((int)(n % 30307)));
            rd.setiz(((int)(n % 30323)));
            rd.setdistribution("uniform");
            result = (OclRandom)(rd);
            return result;
        }


        public static OclRandom newOclRandomBernoulli(double p)
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix(1001);
            rd.setiy(781);
            rd.setiz(913);
            rd.setdistribution("bernoulli");
            rd.setbernoulliP(p);
            result = (OclRandom)(rd);
            return result;
        }


        public static OclRandom newOclRandomNormal(double mu, double vari)
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix(1001);
            rd.setiy(781);
            rd.setiz(913);
            rd.setdistribution("normal");
            rd.setnormalMean(mu);
            rd.setnormalVariance(vari);
            result = (OclRandom)(rd);
            return result;
        }


        public static OclRandom newOclRandomUniform(double lwr, double upr)
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix(1001);
            rd.setiy(781);
            rd.setiz(913);
            rd.setdistribution("uniform");
            rd.setuniformLower(lwr);
            rd.setuniformUpper(upr);
            result = (OclRandom)(rd);
            return result;
        }


        public static OclRandom newOclRandomPoisson(double lm)
        {
            OclRandom result = null;

            OclRandom rd = new OclRandom();
            rd.setix(1001);
            rd.setiy(781);
            rd.setiz(913);
            rd.setdistribution("poisson");
            rd.setpoissonLambda(lm);
            result = (OclRandom)(rd);
            return result;
        }

        public void setSeeds(int x, int y, int z)
        {
            setix(x);
            setiy(y);
            setiz(z);
        }

        public void setSeed(long n)
        {
            setix((int)(n % 30269));
            setiy((int)(n % 30307));
            setiz((int)(n % 30323));
        }

        public double nrandom()
        {
            setix((this.getix() * 171) % 30269);
            setiy((this.getiy() * 172) % 30307);
            setiz((this.getiz() * 170) % 30323);
            return (this.getix() / 30269.0 + this.getiy() / 30307.0 + this.getiz() / 30323.0);
        }


        public double nextDouble()
        {
            double result = 0.0;
            double r = this.nrandom();
            result = (r - ((int)Math.Floor(r)));
            return result;
        }


        public double nextFloat()
        {
            double result = 0.0;

            double r = this.nrandom();
            result = (r - ((int)Math.Floor(r)));
            return result;
        }


        public double nextGaussian()
        {
            double result = 0.0;

            double d = this.nrandom();
            result = d * 2.0 - 3.0;
            return result;
        }


        public int nextInt(int n)
        {
            int result = 0;
            double d = this.nextDouble();
            result = ((int) Math.Floor((d * n)));
            return result;
        }


        public int nextInt()
        {
            int result = 0;

            result = (int) this.nextInt(2147483647);
            return result;
        }


        public long nextLong()
        {
            long result = 0;

            double d = this.nextDouble();
            result = ((long) Math.Floor((d * 9223372036854775807L)));
            return result;
        }


        public bool nextBoolean()
        {
            bool result = false;

            double d = this.nextDouble();
            if (d > 0.5)
            {
                result = true;
            }
            return result;
        }

        public int nextBernoulli(double p)
        {
            int result = 0;

            double d = this.nextDouble();
            if (d > p)
            {
                result = 0;
            }
            else if (d <= p)
            {
                result = 1;
            }
            return result;
        }


        public double nextNormal(double mu, double vari)
        {
            double d = 0.0;

            int i = 0;

            while (i < 12)
            {
                d = d + this.nextDouble();
                i = i + 1;

            }
            d = d - 6;
            return mu + d * Math.Sqrt(vari);
        }

        public double nextUniform(double lwr, double upr)
        {
            double result = 0.0;
            double d = this.nextDouble();
            result = lwr + (upr - lwr) * d;
            return result;
        }

        public double nextPoisson(double lam)
        {
            double x = 0.0;
            double p = Math.Exp(-lam);
            double s = p;
            double u = this.nextDouble();

            while (u > s)
            {
                x = x + 1;
                p = p * lam / x;
                s = s + p;
            }
            return x;
        }

        public double next()
        {
            double result = 0.0;

            if (((string)distribution).Equals("normal"))
            {
                result = this.nextNormal(normalMean, normalVariance);
            }
            else
            {
                if (((string)distribution).Equals("bernoulli"))
                {
                    result = this.nextBernoulli(this.getbernoulliP());
                }
                else
                {
                    if (((string)distribution).Equals("uniform"))
                    {
                        result = this.nextUniform(this.getuniformLower(), this.getuniformUpper());
                    }
                    else
                    {
                        if (((string)distribution).Equals("poisson"))
                        {
                            result = this.nextPoisson(this.getpoissonLambda());
                        }
                        else
                        {
                            result = this.nextDouble();
                        }
                    }
                }
            }
            return result;
        }


        public double mean()
        {
            double result = 0.0;

            if (((string)distribution).Equals("normal"))
            {
                result = this.getnormalMean();
            }
            else
            {
                if (((string)distribution).Equals("bernoulli"))
                {
                    result = this.getbernoulliP();
                }
                else
                {
                    if (((string)distribution).Equals("uniform"))
                    {
                        result = (this.getuniformUpper() + this.getuniformLower()) / 2.0;
                    }
                    else
                    {
                        if (((string)distribution).Equals("poisson"))
                        {
                            result = this.getpoissonLambda();
                        }
                        else
                        {
                            result = 0.5;
                        }
                    }
                }
            }
            return result;
        }

        public double variance()
        {
            double result = 0.0;

            if (((string)distribution).Equals("normal"))
            {
                result = this.getnormalVariance();
            }
            else
            {
                if (((string)distribution).Equals("bernoulli"))
                {
                    result = this.getbernoulliP() * (1 - this.getbernoulliP());
                }
                else
                {
                    if (((string)distribution).Equals("uniform"))
                    {
                        result = (this.getuniformUpper() - this.getuniformLower()) / 12.0;
                    }
                    else
                    {
                        if (((string)distribution).Equals("poisson"))
                        {
                            result = this.getpoissonLambda();
                        }
                        else
                        {
                            result = 1.0 / 12.0;
                        }
                    }
                }
            }
            return result;
        }

        public static ArrayList randomiseSequence(ArrayList sq)
        {
            Random r = new Random();
            ArrayList res = new ArrayList();
            ArrayList old = new ArrayList();
            old.AddRange(sq);
            while (old.Count > 0)
            {
                int x = old.Count;
                if (x == 1)
                {
                    res.Add(old[0]);
                    return res;
                }
                int n = r.Next(x);
                object obj = old[n];
                res.Add(obj);
                old.RemoveAt(n);
            }
            return res;
        }


        public static String randomString(int n)
        {
            Random r = new Random();

            String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
            String res = "";
            for (int i = 0; i < n; i++)
            {
                int code = (int) Math.Floor(r.NextDouble() * 54);
                res = res + characters[code];
            }
            return res;
        }

        public static Object randomElement(ArrayList col)
        {
            Random r = new Random();

            if (col.Count == 0)
            { return null; }
            int n = col.Count;
            int ind = (int) Math.Floor(r.NextDouble() * n);
            return col[ind];
        }

        public static ArrayList randomUniqueElements(ArrayList col, int n)
        {
            Random r = new Random(); 
            ArrayList res = new ArrayList(); 
            int sze = col.Count;
            while (res.Count < n)
            {
                int ind = (int) Math.Floor(r.NextDouble() * sze);
                object x = col[ind];
                if (res.Contains(x)) { }
                else
                { res.Add(x); }
            }
            return res;
        }

        public static ArrayList randomElements(ArrayList col, int n)
        {
            Random r = new Random(); 
            ArrayList res = new ArrayList(); 
            int sze = col.Count;
            while (res.Count < n)
            {
                int ind = (int) Math.Floor(r.NextDouble() * sze);
                object x = col[ind];
                res.Add(x);
            }
            return res;
        }

    }
