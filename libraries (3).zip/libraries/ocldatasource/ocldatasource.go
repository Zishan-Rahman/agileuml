package ocldatasource

import "container/list"
import "fmt"
import "ocl"
import "ocliterator"
import "oclfile"
// import "strings"
// import "math"
import "reflect"
import "database/sql"
// import "os"
// import "github.com/go-sql-driver/mysql"

import "net"
import "net/http"
import "io"

import "ocldate"


type SQLStatement struct {
  text string
  actualStatement *sql.Stmt
  databaseConnection *OclDatasource
  parameterMap map[int]interface{}
  parameters []interface{}
  maxfield int
  resultSet *ocliterator.OclIterator
}

var SQLStatement_instances = list.New()


func createSQLStatement() *SQLStatement {
  var res *SQLStatement
  res = &SQLStatement{}
  SQLStatement_instances.PushBack(res)
  return res
}

func NewSQLStatement() *SQLStatement {
  res := createSQLStatement()
  res.actualStatement = nil
  res.databaseConnection = nil
  res.parameterMap = make(map[int]interface{})
  res.resultSet = nil
  res.maxfield = 0
  return res
}

var TYPESQLStatement = reflect.TypeOf(&SQLStatement{})

func (self *SQLStatement) SetStatement(s *sql.Stmt) { 
   self.actualStatement = s 
}

func (self *SQLStatement) SetConnection(c *OclDatasource) { 
   self.databaseConnection = c 
}

func (self *SQLStatement) Close() {
  if self.actualStatement != nil { 
    self.actualStatement.Close()
    self.actualStatement = nil
  } 
  self.parameterMap = make(map[int]interface{})
  self.parameters = nil
  self.resultSet = nil
  self.maxfield = 0
}

func (self *SQLStatement) CloseOnCompletion() {

}

func (self *SQLStatement) SetString(field int,  value string) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetInt(field int,  value int) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetByte(field int,  value int) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetShort(field int,  value int) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetBoolean(field int,  value bool) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetLong(field int,  value int64) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetDouble(field int,  value float64) {
  self.parameterMap[field] = value
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetTimestamp(field int,  value *ocldate.OclDate) {
  self.parameterMap[field] = value.GetTime()
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) SetNull(field int,  value interface{}) {
  self.parameterMap[field] = nil
  if field > self.maxfield { 
    self.maxfield = field
  } 
}

func (self *SQLStatement) parameterMapToFields() {
    self.parameters = make([]interface{}, self.maxfield)
    for x := 1; x <= self.maxfield; x++ {
      val := self.parameterMap[x] 
      self.parameters[x-1] = val
    } 
}

func (self *SQLStatement) ExecuteUpdate() {
  if self.actualStatement != nil { 
    self.actualStatement.Exec()
  } 
}

func (self *SQLStatement) query_String_Array(parvals []interface{}) *ocliterator.OclIterator {
  var result *ocliterator.OclIterator = nil
  if self.actualStatement != nil { 
    records := list.New()
    rows, _ := self.actualStatement.Query(parvals...)
    
    defer rows.Close()

    var cols []string

    for rows.Next() { 
      cols, _ = rows.Columns()
      m := len(cols) 
      row := make(map[string]interface{})
      values := make([]interface{}, m)
      for i := 0; i < m; i++ { 
        var xi interface{}
        values[i] = &xi
      }
      rows.Scan(values...)
      for i := 0; i < m; i++ { 
        ptr := values[i].(*interface{})
        row[cols[i]] = *ptr
      } 
      records.PushBack(row)
    } 

    result = ocliterator.NewOclIterator_Sequence(records)
    n := len(cols)
    colNames := make([]interface{}, n)
    for i := 0; i < n; i++ { 
      colNames[i] = cols[i]
    } 
    result.SetColumnNames(ocl.SequenceRange(colNames))
  } 

  return result
}

func (self *SQLStatement) ExecuteQuery(stat ...string) *ocliterator.OclIterator {
  var result *ocliterator.OclIterator = nil
  if len(stat) == 0 { 
    self.parameterMapToFields()
    self.resultSet = self.query_String_Array(self.parameters)
    return self.resultSet
  } else { 
    ss := stat[0]
    if self.databaseConnection != nil { 
      self.resultSet = self.databaseConnection.Query_String(ss)
      return self.resultSet
    } 
  } // execute on the databaseConnection
  return result
}

func (self *SQLStatement) update_String_Array(parvals []interface{}) {
  if self.actualStatement != nil { 
    self.actualStatement.Exec(parvals...)
  }
}

func (self *SQLStatement) Execute(stat ...string) {
  if len(stat) == 0 { 
    self.parameterMapToFields()
    self.update_String_Array(self.parameters)
  } else { 
    ss := stat[0]
    if self.databaseConnection != nil { 
      self.databaseConnection.ExecSQL(ss)
    } 
  } // execute on the databaseConnection
}

func (self *SQLStatement) Cancel() {
}

func (self *SQLStatement) GetConnection() *OclDatasource {
  return self.databaseConnection
}

func (self *SQLStatement) GetResultSet() *ocliterator.OclIterator {
  return self.resultSet
}



type OclDatasource struct {
  url string
  protocol string
  host string
  ipaddr *list.List
  file string
  port int
  requestMethod string
  connectionLimit int
  name string
  passwd string
  schema string
  actualDatabase *sql.DB
  internetContents string
  conn *net.Conn
  listener *net.Listener
}

var OclDatasource_instances = list.New()


func createOclDatasource() *OclDatasource {
  var res *OclDatasource
  res = &OclDatasource{}
  OclDatasource_instances.PushBack(res)
  return res
}

var TYPEOclDatasource = reflect.TypeOf(&OclDatasource{})

func GetConnection(url string, name string,  passwd string) *OclDatasource {
  var result *OclDatasource = nil
  var db *OclDatasource = nil
  db = createOclDatasource()
  db.url = url
  db.name = name
  db.passwd = passwd
  /* cfg := mysql.Config{
        User:   name,
        Passwd: passwd,
        Net:    "tcp",
        Addr:   "127.0.0.1:3306",
        DBName: url,
    }
 
  var err error
  var dbase *sql.DB
  dbase, err = sql.Open("mysql", cfg.FormatDSN())
  if err != nil { 
    fmt.Println(err) 
  } 
  db.actualDatabase = dbase */ 

  result = db
  return result
}

func NewOclDatasource() *OclDatasource {
  var result *OclDatasource = nil
  var db *OclDatasource = nil
  db = createOclDatasource()
  db.url = ""
  db.protocol = ""
  db.host = ""
  db.ipaddr = nil
  db.file = ""
  db.port = 0
  db.requestMethod = "GET"
  db.connectionLimit = 0
  db.name = ""
  db.passwd = ""
  db.schema = ""
  db.actualDatabase = nil
  db.internetContents = ""
  db.conn = nil
  db.listener = nil
  result = db
  return result
}

func NewSocket(host string,  port int) *OclDatasource {
  var result *OclDatasource = nil
  var db *OclDatasource = nil
  db = createOclDatasource()
  db.host = host
  db.port = port
  addr := host + ":" + string(port)
  conn, err := net.Dial("tcp", addr)
  if err == nil { 
    db.conn = &conn
  } 
  result = db
  return result
}

func newServerSocket(port int, limit int) *OclDatasource {
  var db *OclDatasource = createOclDatasource()
  db.port = port
  db.connectionLimit = limit
  ln, err := net.Listen("tcp", ":8080")
  if err == nil { 
    db.listener = &ln
  } 
  return db
}

func (self *OclDatasource) accept() *OclDatasource {
  if self.listener == nil { 
    return self
  } 

  lstnr := *self.listener

  for {
    conn, err := lstnr.Accept()
    if err == nil {
      self.conn = &conn
      return self
    }
  } 
  return self
}

func NewURL(s string) *OclDatasource {
  var result *OclDatasource = nil
  var db *OclDatasource = nil
  db = createOclDatasource()
  db.url = s
  result = db
  return result
}

func NewURL_PHF(p string, h string,  f string) *OclDatasource {
  var result *OclDatasource = nil
  var db *OclDatasource = nil
  db = createOclDatasource()
  db.protocol = p
  db.host = h
  db.file = f
  db.url = p + "://" + h + "/" + f
  result = db
  return result
}

func NewURL_PHNF(p string, h string, n int,  f string) *OclDatasource {
  var result *OclDatasource = nil
  var db *OclDatasource = nil
  db = createOclDatasource()
  db.protocol = p
  db.host = h
  db.port = n
  db.file = f
  db.url = p + "://" + h + ":" + string(n) + "/" + f
  result = db
  return result
}

func (self *OclDatasource) CreateStatement() *SQLStatement {
  return self.Prepare("")
}

func (self *OclDatasource) Prepare(stat string) *SQLStatement {
  var ss *SQLStatement = NewSQLStatement()
  ss.text = stat
  ss.databaseConnection = self
  if self.actualDatabase != nil { 
    stmt, _ := self.actualDatabase.Prepare(stat)
    ss.actualStatement = stmt
  } 
  return ss
}

func (self *OclDatasource) PrepareStatement(stat string) *SQLStatement {
  return self.Prepare(stat)
}

func (self *OclDatasource) PrepareCall(stat string) *SQLStatement {
  return self.Prepare(stat)
}

func (self *OclDatasource) Query_String(stat string) *ocliterator.OclIterator {
  var result *ocliterator.OclIterator = nil
  if self.actualDatabase != nil { 
    records := list.New()
    rows, err := self.actualDatabase.Query(stat)
    fmt.Println(err)
    defer rows.Close()

    var cols []string

    for rows.Next() { 
      cols, _ = rows.Columns()
      m := len(cols) 
      row := make(map[string]interface{})
      values := make([]interface{}, m)
      for i := 0; i < m; i++ { 
        var xi interface{}
        values[i] = &xi
      }
      rows.Scan(values...)
      for i := 0; i < m; i++ { 
        ptr := values[i].(*interface{})
        row[cols[i]] = *ptr
      } 
      records.PushBack(row)
    } 

    result = ocliterator.NewOclIterator_Sequence(records)

    n := len(cols)
    colNames := make([]interface{}, n)
    for i := 0; i < n; i++ { 
      colNames[i] = cols[i]
    } 
    result.SetColumnNames(ocl.SequenceRange(colNames))
  } 
  return result
}

func (self *OclDatasource) RawQuery(stat string,  pos *list.List) *ocliterator.OclIterator {
  var result *ocliterator.OclIterator = nil
  parvals := ocl.AsArray(pos)
  if self.actualDatabase != nil { 
    records := list.New()
    rows, err := self.actualDatabase.Query(stat, parvals...)
    fmt.Println(err)
    defer rows.Close()

    var cols []string

    for rows.Next() { 
      cols, _ = rows.Columns()
      m := len(cols) 
      row := make(map[string]interface{})
      values := make([]interface{}, m)
      for i := 0; i < m; i++ { 
        var xi interface{}
        values[i] = &xi
      }
      rows.Scan(values...)
      for i := 0; i < m; i++ { 
        ptr := values[i].(*interface{})
        row[cols[i]] = *ptr
      } 
      records.PushBack(row)
    } 

    result = ocliterator.NewOclIterator_Sequence(records)
    n := len(cols)
    colNames := make([]interface{}, n)
    for i := 0; i < n; i++ { 
      colNames[i] = cols[i]
    } 
    result.SetColumnNames(ocl.SequenceRange(colNames))
  } 

  return result

}

func (self *OclDatasource) NativeSQL(stat string) string {
  var result string = ""
  if self.actualDatabase != nil { 
    rows, _ := self.actualDatabase.Query(stat)
    defer rows.Close()

    var cols []string

    for rows.Next() { 
      cols, _ = rows.Columns()
      m := len(cols) 

      values := make([]interface{}, m)
      for i := 0; i < m; i++ { 
        var xi interface{}
        values[i] = &xi
      }
      rows.Scan(values...)
      ptr := values[0].(*interface{})
      return ocl.ToStringOclAny(*ptr)
    } 
  } 
  return result
}

func (self *OclDatasource) Query_String_Sequence(stat string,  cols *list.List) *ocliterator.OclIterator {
  return self.Query_String(stat)
}

func (self *OclDatasource) query_String_Array(stat string,  parvals []interface{}) *ocliterator.OclIterator {
  var result *ocliterator.OclIterator = nil
  if self.actualDatabase != nil { 
    records := list.New()
    rows, _ := self.actualDatabase.Query(stat, parvals...)
    
    defer rows.Close()

    var cols []string

    for rows.Next() { 
      cols, _ = rows.Columns()
      m := len(cols) 
      row := make(map[string]interface{})
      values := make([]interface{}, m)
      for i := 0; i < m; i++ { 
        var xi interface{}
        values[i] = &xi
      }
      rows.Scan(values...)
      for i := 0; i < m; i++ { 
        ptr := values[i].(*interface{})
        row[cols[i]] = *ptr
      } 
      records.PushBack(row)
    } 

    result = ocliterator.NewOclIterator_Sequence(records)
    n := len(cols)
    colNames := make([]interface{}, n)
    for i := 0; i < n; i++ { 
      colNames[i] = cols[i]
    } 
    result.SetColumnNames(ocl.SequenceRange(colNames))
  } 

  return result
}

func (self *OclDatasource) ExecSQL(stat string) {
  if self.actualDatabase != nil { 
    self.actualDatabase.Exec(stat)
  } 
}

func (self *OclDatasource) Abort() {

}

func (self *OclDatasource) Close() {
  self.actualDatabase = nil
  self.conn = nil
  self.ipaddr = nil
}

func (self *OclDatasource) Commit() {
}

func (self *OclDatasource) Rollback() {
}

 
func (self *OclDatasource) connect() { 
  resp, err := http.Get(self.url)
  if err != nil { 
    return
  } 
  defer resp.Body.Close()
  body, err := io.ReadAll(resp.Body)
  if err != nil { 
    self.internetContents = string(body)
  } 
} 

func (self *OclDatasource) openConnection() *OclDatasource {
  return self
}

func (self *OclDatasource) SetRequestMethod( method string) {
  self.requestMethod = method
}

func (self *OclDatasource) SetSchema( s string) {
  self.schema = s
}

func (self *OclDatasource) GetSchema() string {
  var result string = ""
  result = self.schema
  return result
}

func (self *OclDatasource) getInputStream() *oclfile.OclFile {
  if self.conn != nil { 
    fle := oclfile.NewOclFile(self.url)
    return oclfile.NewOclFile_Remote(fle,*self.conn)
  } 
  var res *oclfile.OclFile = oclfile.NewOclFile(self.url)
  res.SetInputStream(self.internetContents)
  return oclfile.NewOclFile_Read(res)
}

func (self *OclDatasource) getOutputStream() *oclfile.OclFile {
  if self.conn != nil { 
    fle := oclfile.NewOclFile(self.url)
    return oclfile.NewOclFile_Remote(fle,*self.conn)
  } 
  return nil
}

func (self *OclDatasource) GetURL() string {
  var result string = ""
  result = self.url
  return result
}

func (self *OclDatasource) getContent() interface{} {
  var result interface{} = 0
  return result
}

func (self *OclDatasource) GetFile() string {
  var result string = ""
  result = self.file
  return result
}

func (self *OclDatasource) GetHost() string {
  var result string = ""
  result = self.host
  return result
}

func GetLocalHost() *OclDatasource {
  var result *OclDatasource = nil
  var d *OclDatasource = nil
  d = createOclDatasource()
  d.host = "localhost"
  d.ipaddr = ocl.InitialiseSequence(127,0,0,1)
  result = d
  return result
}

func (self *OclDatasource) GetAddress() *list.List {
  var result *list.List = list.New()
  result = self.ipaddr
  return result
}

func (self *OclDatasource) GetPort() int {
  var result int = 0
  result = self.port
  return result
}

func (self *OclDatasource) GetProtocol() string {
  var result string = ""
  result = self.protocol
  return result
}

/* func assignValues(vals ...interface{}) { 
  n := len(vals)
  for i := 0; i < n; i++ { 
    ptr := vals[i].(*interface{})
    *ptr = i
  } 
} 

func main() { 
  cols := ocl.InitialiseSequence("a", "b", "c")
  row := make(map[string]interface{})
  values := make([]interface{}, 3)
  
  for i := 0; i < 3; i++ { 
    var xi interface{}
    values[i] = &xi
  }
  
//  *values[0] = 0
//  *values[1] = 1
//  *values[2] = 2

  assignValues(values...)

  for i := 0; i < 3; i++ { 
     ptr := values[i].(*interface{})
     row[(ocl.At(cols,i+1)).(string)] = *ptr
  } 
  fmt.Println(row["b"])
} 

*/ 

