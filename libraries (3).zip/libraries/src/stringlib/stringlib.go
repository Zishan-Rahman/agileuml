package stringlib

import "fmt"
import "container/list"
import "ocl"
import "strings"
// import "reflect"
  

func Format(f string, args *list.List) string {
  arglist := ocl.AsArray(args)
  return fmt.Sprintf(f, arglist...)
} 

func Scan(s string, f string) *list.List { 
  // count %'s in f to identify size of result
 
  n := strings.Count(f,"%")
  res := make([]interface{}, n)
  for i := 0; i < n; i++ { 
    var v interface{}
    res[i] = &v
  } 
  fmt.Sscanf(s,f,res...)
  return ocl.SequenceRange(res)
}


/* func main() {
  lst := Scan("100 3.3 text", "%d %f %s")
  for x := lst.Front(); x != nil; x = x.Next() { 
    ptr := x.Value.(*interface{})
    fmt.Println(*ptr)
  } 
} */ 


  



