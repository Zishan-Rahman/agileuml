class MathLib
{ 
 private:
  static int ix;
  static int iy;
  static int iz;
  static vector<string>* hexdigit;

 public:
   MathLib() {
     ix = 0;
     iy = 0;
     iz = 0;
     hexdigit = (new vector<string>());
  }

  static void setix(int ix_x) { ix = ix_x; }

  static void setiy(int iy_x) { iy = iy_x; }

  static void setiz(int iz_x) { iz = iz_x; }

  static void sethexdigit(vector<string>* hexdigit_x) 
  { hexdigit = hexdigit_x; }

  static void sethexdigit(int _ind, string hexdigit_x)   
  { (*hexdigit)[_ind] = hexdigit_x; }

  static void addhexdigit(string hexdigit_x)
  { hexdigit->push_back(hexdigit_x); }

  static int getix() { return ix; }

  static int getiy() { return iy; }
  
  static int getiz() { return iz; }
  
  static vector<string>* gethexdigit() { return hexdigit; }
  
  static double pi();

  static double e();

  static void setSeeds(int x,int y,int z);

  static double nrandom();

  static double random();

  static long combinatorial(int n,int m);

  static long factorial(int x);

  static double asinh(double x);

  static double acosh(double x);

  static double atanh(double x);

  static string decimal2bits(long x);

  static string decimal2binary(long x);

  static string decimal2oct(long x);

  static string decimal2octal(long x);

  static string decimal2hx(long x);

  static string decimal2hex(long x);

  static int bitwiseAnd(int x,int y);

  static int bitwiseOr(int x,int y);

  static int bitwiseXor(int x,int y);

  static int bitwiseNot(int x);

  static long bitwiseAnd(long x, long y);

  static long bitwiseOr(long x, long y);

  static long bitwiseXor(long x, long y);

  static long bitwiseNot(long x);

  static vector<bool>* toBitSequence(long x);

  static long modInverse(long n,long p);

  static long modPow(long n,long m,long p);

  static inline long doubleToLongBits(double x) {
    uint64_t bits;
    memcpy(&bits, &x, sizeof bits);
    return long(bits);
  }

  static inline double longBitsToDouble(long x) {
    uint64_t bits;
    memcpy(&bits, &x, sizeof bits);
    return double(bits);
  }

    static double discountDiscrete(double amount, double rate, double time)
    {
        double result = 0;
        result = 0.0;
        if ((rate <= -1 || time < 0))
        {
            return result;
        }

        result = amount / pow((1 + rate), time);
        return result;
    }

    static double bisectionDiscrete(double r, double rl, double ru,
        vector<double>* values); 

    static double netPresentValueDiscrete(double rate, vector<double>* values)
    {
        double result = 0;
        result = 0.0;
        if ((rate <= -1))
        {
            return result;
        }

        int upper = values->size();
        int i = 0;
        for (; i < upper; i++)
        {
            result = result + discountDiscrete(values->at(i), rate, i);
        }
        return result;
    }


    static double irrDiscrete(vector<double>* values)
    {
        double res = bisectionDiscrete(0.1, -0.5, 1.0, values);
        return res;
    }

    static double roundN(double x, int n)
    {
        if (n < 0)
        {
            return round(x);
        }
        double y = x * pow(10, n);
        return round(y) / pow(10, n);
    }

    static double truncateN(double x, int n)
    {
        if (n < 0)
        {
            return (int)x;
        }
        double y = x * pow(10, n);
        return ((int)y) / pow(10, n);
    }

    static double toFixedPoint(double x, int m, int n)
    {
        if (m < 0 || n < 0)
        {
            return x;
        }
        int y = (int)(x * pow(10, n));
        int z = y % ((int) pow(10, m + n));
        return z / pow(10.0, n);
    }

    static double toFixedPointRound(double x, int m, int n)
    {
        if (m < 0 || n < 0)
        {
            return x;
        }
        int y = (int) round(x * pow(10, n));
        int z = y % ((int) pow(10, m + n));
        return z / pow(10.0, n);
    }


  ~MathLib() {
  }

};
