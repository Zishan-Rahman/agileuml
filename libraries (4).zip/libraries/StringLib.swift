import Foundation
import Darwin


class StringLib
{ 
  static func format(fmt : String, sq : [CVarArg]) -> String
  { let swiftfmt = fmt.replacingOccurrences(of: "%s", with: "%@")
    let txt = String(format: swiftfmt, arguments: sq)
    return txt
  }
}




