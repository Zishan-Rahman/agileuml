    class StringLib
    {
        public static string format(string f, ArrayList sq)
        {
            object[] args = new object[sq.Count];
            for (int i = 0; i < sq.Count; i++)
            { args[i] = sq[i]; }
            string fmt = OclFile.convertConversionFormat(f);
            string formattedString = String.Format(fmt, args);
            return formattedString; 
        }

    }
