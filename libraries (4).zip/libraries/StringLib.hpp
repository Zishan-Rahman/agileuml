// StringLib.h


using namespace std;


class StringLib
{ public: 
   static string format(string f, vector<void*>* sq);
};

